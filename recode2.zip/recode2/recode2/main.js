let myapi = 'ZpJX3cXA19hEpAMHTz6AfHq8W8FTYnvaGOBworIs2x2mSqMSrc8gLoiF';


const API_KEY = 'ZpJX3cXA19hEpAMHTz6AfHq8W8FTYnvaGOBworIs2x2mSqMSrc8gLoiF'; // իմնա կարաէ օգտագօրծեք
const searchForm = document.getElementById('searchForm'); // ես վերցնում եմ ուղակի որ submit կարդամ
const searchInput = document.getElementById('searchInput');
const resultsDiv = document.getElementById('results');

searchForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const query = searchInput.value.trim();
    if (!query) return; // վոնց հասկացա մենակ պռօբելի համարա որ մենակ պռօբել չուղարկեն. մնացած դեպքերը input required պաշտպանումա. 

    resultsDiv.innerHTML = 'Загрузка...';

    try {
        const response = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=10`, {
            headers: {
                Authorization: API_KEY
            }
        });

        const data = await response.json();
        if (!data.photos.length) {
            resultsDiv.innerHTML = 'Nothing found.';
            return;
        }



        function chooseOne(selectedId) {
            let images=resultsDiv.querySelectorAll('img')
            images.forEach(img=>{
                if(img.id!=selectedId){
                    img.style.display='none'
                }else{
               
                    img.style.width='300px'
                    img.style.height='300px'
                }
            })
       

        
         }

        resultsDiv.innerHTML = '';
        data.photos.forEach(photo => {
            const img = document.createElement('img');
            img.src = photo.src.medium;
            img.alt = photo.photographer;
            img.id=photo.id
            img.addEventListener('click', ()=>chooseOne(photo.id))

            resultsDiv.appendChild(img);
        });
    } catch (error) {
        resultsDiv.innerHTML = 'An error occurred while fetching data.';
        console.error(error);
    }
});
